// =====================================================
// GRAVE RIDER — THE BIKE AND RIDER (Planck.js physics)
//
// Modelled on a real electric motocross bike (see js/config.js for
// every number and where it comes from):
//   chassis  = frame, battery, motor, seat, plastics (one body)
//   wheels   = on wheel joints: each slides along the fork / shock line
//              on a spring + damper with real travel and hard stops.
//              The rear one is driven by the electric motor (chain,
//              single speed); both have brakes.
//   rider    = separate body standing on the footpegs; leans with the
//              arrow keys and falls off when you crash
//
// Units are metres, kilograms, seconds. y grows DOWNWARD.
// =====================================================
var Bike = (function () {
  var pl = planck, Vec2 = pl.Vec2;
  var BIKE_GROUP = -1; // bike parts never collide with each other
  var RAKE = 27.3 * Math.PI / 180; // steering head angle [SPEC]

  // --- Real geometry in metres, relative to the chassis origin, with the
  // suspension fully extended. The origin sits 0.641 m above the ground. ---
  var GEO = {
    rearAxle:   { x: -0.720, y: 0.300 },  // wheelbase 1.487 m [SPEC]
    frontAxle:  { x: 0.767, y: 0.293 },   // (front tyre is 7 mm taller)
    rearAxis:   { x: 0.0995, y: 0.995 },  // rear wheel moves along this (down)
    frontAxis:  { x: Math.sin(RAKE), y: Math.cos(RAKE) }, // along the fork (down)
    forkTop:    { x: 0.380, y: -0.460 },
    swingPivot: { x: -0.120, y: 0.100 },
    footpeg:    { x: -0.080, y: 0.220 },
    grip:       { x: 0.280, y: -0.520 },
    // bike centre of mass (battery + motor sit low) [ESTIMATE]
    centreOfMass: { x: 0.020, y: 0.050 },
    // collision outline of the bike body (for crashes / belly landings)
    body: [{ x: -0.55, y: -0.38 }, { x: 0.40, y: -0.48 }, { x: 0.50, y: -0.30 },
           { x: 0.25, y: 0.27 }, { x: -0.30, y: 0.27 }],
    // rider (6 ft / 1.83 m) standing in the attack position, relative to
    // the footpeg. These shapes are only for crashes and drawing; the
    // rider's weight is set separately (see riderMassData).
    shoulder:   { x: 0.0, y: -1.16 },
    head:       { x: 0.091, y: -1.41, r: 0.148 },
    torso:      { x: -0.159, y: -0.955, hw: 0.136, hh: 0.284, angle: 0.58 },
    // whole-body centre of mass in gear, legs included: 0.84 m above the
    // pegs, over them [ESTIMATE: body-segment model, de Leva 1996 masses]
    riderCentre: { x: 0.02, y: -0.84 },
    riderInertia: 12.5      // pitch inertia about that point, kg·m² [ESTIMATE: same model]
  };

  function v(p) { return Vec2(p.x, p.y); }
  function add(a, b) { return Vec2(a.x + b.x, a.y + b.y); }

  function makeBody(world, type, pos, label) {
    return world.createBody({
      type: type, position: pos, allowSleep: false, userData: label
    });
  }

  // --- Build a new bike with its chassis origin at (x, y) metres ---
  function create(world, x, y) {
    var origin = Vec2(x, y);

    // Chassis: everything except the wheels
    var chassis = makeBody(world, "dynamic", origin, "chassis");
    chassis.createFixture({
      shape: pl.Polygon(GEO.body.map(v)), density: 1,
      friction: 0.5, filterGroupIndex: BIKE_GROUP, userData: "chassis"
    });
    var chassisMass = CONFIG.bikeMass - CONFIG.frontWheelMass - CONFIG.rearWheelMass;
    chassis.setMassData({
      mass: chassisMass, center: v(GEO.centreOfMass),
      I: chassisMass * (1.4 * 1.4 + 0.6 * 0.6) / 12 // pitch inertia of a 1.4 × 0.6 m block
    });

    function makeWheel(axlePos, axisDir, travel, preload, radius, mass, inertia) {
      var pos = add(origin, axlePos);
      var wheel = makeBody(world, "dynamic", pos, "wheel");
      wheel.createFixture({
        shape: pl.Circle(radius), density: 1,
        friction: CONFIG.wheelGrip, restitution: 0,
        filterGroupIndex: BIKE_GROUP, userData: "wheel"
      });
      wheel.setMassData({ mass: mass, center: Vec2(0, 0), I: inertia });
      // Wheel joint = suspension spring + damper along the fork/shock line,
      // and a motor (electric motor on the rear, brakes on both).
      // The spring's resting point is "preload" metres further out than full
      // extension, so the spring is already pushing when the bike is in the air.
      var joint = world.createJoint(pl.WheelJoint({
        bodyA: chassis, bodyB: wheel,
        localAnchorA: Vec2(axlePos.x + axisDir.x * preload, axlePos.y + axisDir.y * preload),
        localAnchorB: Vec2(0, 0),
        localAxisA: v(axisDir),
        enableMotor: false, maxMotorTorque: 0, motorSpeed: 0,
        frequencyHz: 1, dampingRatio: 0.5
      }));
      // Hard stops at both ends of the travel (two "ropes" along the axis:
      // one stops the wheel dropping past full extension, one stops it
      // squashing past full travel = bottoming out)
      world.createJoint(pl.RopeJoint({
        bodyA: chassis, bodyB: wheel, localAnchorB: Vec2(0, 0),
        localAnchorA: Vec2(axlePos.x - axisDir.x, axlePos.y - axisDir.y), maxLength: 1
      }));
      world.createJoint(pl.RopeJoint({
        bodyA: chassis, bodyB: wheel, localAnchorB: Vec2(0, 0),
        localAnchorA: Vec2(axlePos.x + axisDir.x, axlePos.y + axisDir.y), maxLength: 1 + travel
      }));
      return { wheel: wheel, joint: joint, travel: travel, preload: preload, axis: axisDir, radius: radius };
    }

    var Rf = CONFIG.frontWheelRadius, Rr = CONFIG.rearWheelRadius;
    // Rear wheel inertia includes the motor's spinning parts seen through the chain
    var rear = makeWheel(GEO.rearAxle, GEO.rearAxis, CONFIG.rearTravel, CONFIG.rearPreload,
      Rr, CONFIG.rearWheelMass, CONFIG.drivetrainInertia);
    var front = makeWheel(GEO.frontAxle, GEO.frontAxis, CONFIG.frontTravel, CONFIG.frontPreload,
      Rf, CONFIG.frontWheelMass, CONFIG.frontWheelMass * 0.3 * 0.3 * 0.85);

    // Rider: stands on the footpegs, can lean back and forward
    var pegPos = add(origin, GEO.footpeg);
    var rider = makeBody(world, "dynamic", pegPos, "rider");
    var T = GEO.torso, H = GEO.head;
    rider.createFixture({
      shape: pl.Box(T.hw, T.hh, Vec2(T.x, T.y), T.angle), density: 1,
      friction: 0.6, filterGroupIndex: BIKE_GROUP, userData: "torso"
    });
    rider.createFixture({
      shape: pl.Circle(Vec2(H.x, H.y), H.r), density: 1,
      friction: 0.6, filterGroupIndex: BIKE_GROUP, userData: "head"
    });
    // The rider's real weight distribution (the shapes alone would leave out
    // the legs and put the weight far too high). Planck wants the inertia
    // about the body's origin (the footpeg), so add m × distance².
    var rc = GEO.riderCentre;
    rider.setMassData({
      mass: CONFIG.riderMass, center: v(rc),
      I: GEO.riderInertia + CONFIG.riderMass * (rc.x * rc.x + rc.y * rc.y)
    });
    // Legs: the rider stands on the pegs and bends their knees to soak up
    // landings (a spring + damper along the bike's up/down line), and leans
    // forward/back at the pegs (the joint's motor turns the rider).
    // The spring's rest point is raised by weight ÷ stiffness, so standing
    // still the rider is exactly in the attack position.
    var legPreload = CONFIG.riderMass * 9.81 * CONFIG.gravity / CONFIG.legStiffness;
    var hips = world.createJoint(pl.WheelJoint({
      bodyA: chassis, bodyB: rider,
      localAnchorA: Vec2(GEO.footpeg.x, GEO.footpeg.y - legPreload),
      localAnchorB: Vec2(0, 0), localAxisA: Vec2(0, 1),
      enableMotor: true, maxMotorTorque: CONFIG.riderStrength, motorSpeed: 0,
      frequencyHz: 2, dampingRatio: 0.5
    }));
    // How far the legs can bend (deep crouch) and straighten: two "ropes",
    // like the wheels' hard stops
    var legStops = [
      world.createJoint(pl.RopeJoint({ bodyA: chassis, bodyB: rider, localAnchorB: Vec2(0, 0),
        localAnchorA: Vec2(GEO.footpeg.x, GEO.footpeg.y - 1), maxLength: 1 + CONFIG.legCrouch })),
      world.createJoint(pl.RopeJoint({ bodyA: chassis, bodyB: rider, localAnchorB: Vec2(0, 0),
        localAnchorA: Vec2(GEO.footpeg.x, GEO.footpeg.y + 1), maxLength: 1 + CONFIG.legStretch }))
    ];

    var bike = {
      world: world,
      chassis: chassis,
      rider: rider,
      hips: hips,         // legs + lean joint (pegs to rider)
      legStops: legStops,
      crouch: 0,          // how far the legs are bent from the attack position (m)
      riderG: 0,          // rider's up/down acceleration in g (averaged over 3 steps)
      riderVel: null,
      riderAccel: [0, 0, 0],
      rear: rear,
      front: front,
      rearOnGround: false,
      frontOnGround: false,
      bodyOnGround: false, // the frame itself is touching the ground (stuck on its belly)
      rearAir: 99,   // steps since each wheel last touched the ground
      frontAir: 99,
      riderHit: false,
      crashed: false,
      groundAngle: 0, // slope under the rear tyre (radians, 0 = flat)
      traction: 1,    // traction control's power share (0.15..1)
      mu: null,       // grip and bounce last set on the tyres (see applyTuning)
      bounce: null,
      frontLoad: 0,   // how hard each tyre presses on the ground (N), from last step
      rearLoad: 0,
      slipFront: 0,   // how much faster/slower each tyre surface moves than the ground (m/s)
      slipRear: 0,
      absFront: 1,    // brake assist's share of braking left on each wheel
      absRear: 1,
      rearDrive: 0    // forward push of the ground on the rear tyre last step (N)
    };
    suspension(bike);
    return bike;
  }

  function remove(world, bike) {
    [bike.chassis, bike.rider, bike.rear.wheel, bike.front.wheel]
      .forEach(function (b) { world.destroyBody(b); });
  }

  function onGround(bike) {
    return bike.rearOnGround || bike.frontOnGround;
  }

  // Anything of the bike touching the ground (wheels or the frame) = not in the air
  function touching(bike) {
    return onGround(bike) || bike.bodyOnGround;
  }

  // How far each end is squashed from full extension (m)
  function compression(s) {
    return -(s.joint.getJointTranslation() + s.preload);
  }

  // --- Copy slider values (grip, bounce) onto the live bike ---
  // Planck mixes the tyre's and the ground's friction as √(tyre × ground),
  // and the ground is 1, so the tyre gets grip² to make the real friction
  // coefficient exactly wheelGrip × the level's friction.
  function applyTuning(bike, surfaceFriction, bounce) {
    var mu = CONFIG.wheelGrip * surfaceFriction;
    if (bike.mu === mu && bike.bounce === bounce) return;
    bike.mu = mu; bike.bounce = bounce;
    [bike.rear.wheel, bike.front.wheel].forEach(function (w) {
      var f = w.getFixtureList();
      f.setFriction(mu * mu);
      f.setRestitution(bounce);
      // A contact keeps the friction it started with, so update the ones
      // already touching (otherwise a change only applies after a jump)
      for (var ce = w.getContactList(); ce; ce = ce.next) {
        ce.contact.resetFriction();
        ce.contact.resetRestitution();
      }
    });
  }

  // Set a Planck WheelJoint spring to a real spring rate k (N/m) and damping
  // ratio. Planck rates a spring against the mass it sees along the joint's
  // line: both bodies, including how much a push along the line turns them.
  function setSpring(joint, A, B, at, ax, k, zeta, sprung) {
    var inv = 0;
    [A, B].forEach(function (b) {
      var c = b.getWorldCenter(), I = b.getInertia() - b.getMass() * Vec2.lengthSquared(b.getLocalCenter());
      var lever = (at.x - c.x) * ax.y - (at.y - c.y) * ax.x;
      inv += 1 / b.getMass() + lever * lever / I;
    });
    var mEff = 1 / inv;
    joint.setSpringFrequencyHz(Math.sqrt(k / mEff) / (2 * Math.PI));
    joint.setSpringDampingRatio(zeta * Math.sqrt(sprung / mEff));
  }

  // --- Suspension springs and dampers. Called every step. ---
  // Planck describes a spring by how fast it would bounce the mass it sees
  // along the suspension line (chassis + wheel, including the chassis
  // turning), so convert the real spring rate (N/m) and damping into that.
  function suspension(bike) {
    var sprungTotal = CONFIG.bikeMass - CONFIG.frontWheelMass - CONFIG.rearWheelMass + CONFIG.riderMass;
    var c = bike.chassis;
    [[bike.rear, CONFIG.rearSpringRate, CONFIG.rearDamping, 0.55],
     [bike.front, CONFIG.frontSpringRate, CONFIG.frontDamping, 0.45]].forEach(function (e) {
      var s = e[0], k = e[1] * CONFIG.suspensionStiffness, zeta = e[2];
      var sprung = sprungTotal * e[3];   // weight carried by this end [ESTIMATE: 55% rear]
      setSpring(s.joint, c, s.wheel, s.wheel.getPosition(), c.getWorldVector(v(s.axis)), k, zeta, sprung);

      // Bottoming cushion: real forks (hydraulic cones) and shocks (bump
      // stops) get much stiffer in the last 15% of travel
      var deep = compression(s) - 0.85 * s.travel;
      var cushion = s === bike.rear ? CONFIG.rearBottoming : CONFIG.bottomingStiffness;
      if (deep > 0) pushApart(bike, s, cushion * k * deep);
    });

    // Rear linkage: stiffer deeper in the stroke. Adds what the wheel-force
    // table has beyond the straight spring, but only past the sag point so
    // the ride height stays as set.
    var rc = compression(bike.rear);
    if (rc > 0.105 && CONFIG.rearForceTable.length) {
      var want = tableAt(CONFIG.rearForceTable, rc) * CONFIG.suspensionStiffness;
      var have = CONFIG.rearSpringRate * CONFIG.suspensionStiffness * (rc + CONFIG.rearPreload);
      var extra = want - have;
      var atSag = tableAt(CONFIG.rearForceTable, 0.105) * CONFIG.suspensionStiffness - CONFIG.rearSpringRate * CONFIG.suspensionStiffness * (0.105 + CONFIG.rearPreload);
      if (extra - atSag > 0) pushApart(bike, bike.rear, extra - atSag);
    }

    // The rider's legs
    if (bike.hips) {
      setSpring(bike.hips, c, bike.rider, bike.rider.getPosition(), c.getWorldVector(Vec2(0, 1)),
        CONFIG.legStiffness, CONFIG.legDamping, CONFIG.riderMass);
    }

    // Legs' rest point follows the gravity actually in use (level, zone, slider)
    if (bike.hips) {
      bike.hips.getLocalAnchorA().y = GEO.footpeg.y - CONFIG.riderMass * Vec2.lengthOf(bike.world.getGravity()) / CONFIG.legStiffness;
    }

    // Anti-squat: accelerating moves weight onto the rear wheel. On a real
    // bike the chain pull and swingarm angle hold the rear up against this
    // (otherwise the rear sinks and tips the nose up). This rear wheel slides
    // on a straight line, so add that holding force along the shock.
    if (bike.rearDrive > 0 && CONFIG.antiSquat > 0) {
      var transfer = bike.rearDrive * comHeight(bike) / wheelbase(bike); // N moved onto the rear
      pushApart(bike, bike.rear, CONFIG.antiSquat * transfer);
    }
  }

  // Linear lookup in a [[x, y], ...] table
  function tableAt(t, x) {
    if (x <= t[0][0]) return t[0][1];
    for (var i = 1; i < t.length; i++) {
      if (x <= t[i][0]) return t[i - 1][1] + (t[i][1] - t[i - 1][1]) * (x - t[i - 1][0]) / (t[i][0] - t[i - 1][0]);
    }
    return t[t.length - 1][1];
  }

  // Tyre grip depends on slip: set each wheel contact's friction from how
  // fast the tyre surface moves compared with the ground (spin or skid).
  function tyreGrip(bike) {
    [bike.rear, bike.front].forEach(function (s) {
      var w = s.wheel, isFront = s === bike.front, load = 0, slipMax = 0;
      for (var ce = w.getContactList(); ce; ce = ce.next) {
        var ct = ce.contact;
        if (!ct.isTouching() || !ct.isEnabled() || ce.other.getUserData() !== "ground") continue;
        var n = ct.getWorldManifold(null).normal, sign = ct.getFixtureB().getBody() === w ? 1 : -1;
        // rolling direction along the ground (to the right of the bike)
        var tx = -sign * n.y, ty = sign * n.x;
        if (tx < 0) { tx = -tx; ty = -ty; }
        var v = w.getLinearVelocity();
        var slip = Math.abs(w.getAngularVelocity() * s.radius - (v.x * tx + v.y * ty));
        var share = slip <= CONFIG.slipFull ? 1 :
          1 - (1 - CONFIG.slidingGrip) * Math.min(1, (slip - CONFIG.slipFull) / Math.max(0.1, CONFIG.slipSliding - CONFIG.slipFull));
        ct.setFriction((bike.mu || 0) * share);
        slipMax = Math.max(slipMax, slip);
        var m = ct.getManifold();
        for (var k = 0; k < m.pointCount; k++) load += m.points[k].normalImpulse / CONFIG.physicsStepSec;
      }
      if (isFront) { bike.slipFront = slipMax; bike.frontLoad = load; }
      else { bike.slipRear = slipMax; bike.rearLoad = load; }
    });
  }

  // Push a wheel out along its suspension line (and the frame the other way)
  function pushApart(bike, s, force) {
    var dir = bike.chassis.getWorldVector(v(s.axis));
    var at = s.wheel.getPosition();
    s.wheel.applyForce(Vec2(dir.x * force, dir.y * force), at, true);
    bike.chassis.applyForce(Vec2(-dir.x * force, -dir.y * force), at, true);
  }

  function wheelbase(bike) {
    var a = bike.rear.wheel.getPosition(), b = bike.front.wheel.getPosition();
    return Math.hypot(b.x - a.x, b.y - a.y);
  }

  // Height of the bike + rider's centre of mass above the rear tyre's contact
  function comHeight(bike) {
    var m = 0, x = 0, y = 0;
    [bike.chassis, bike.rider, bike.rear.wheel, bike.front.wheel].forEach(function (b) {
      var c = b.getWorldCenter(), bm = b.getMass();
      m += bm; x += c.x * bm; y += c.y * bm;
    });
    var up = bike.chassis.getWorldVector(Vec2(0, -1)), r = bike.rear.wheel.getPosition();
    return (x / m - r.x) * up.x + (y / m - r.y) * up.y + bike.rear.radius;
  }

  // --- Air drag and rolling resistance. Called every step. ---
  function resistance(bike, gravity) {
    var c = bike.chassis, vel = c.getLinearVelocity();
    var speed = Math.hypot(vel.x, vel.y);
    if (speed < 0.05) return;
    var ux = vel.x / speed, uy = vel.y / speed;
    // Air drag: ½ × air density × (drag × area) × speed²
    var drag = 0.5 * CONFIG.airDensity * CONFIG.dragArea * speed * speed;
    c.applyForce(Vec2(-ux * drag, -uy * drag), c.getWorldCenter(), true);
    // Rolling resistance on each wheel touching the ground (on a slope the
    // tyres press on the ground with only cos(slope) of the weight)
    var g = bike.world.getGravity(); // how much of the weight presses on the ground: measured from "down"
    var load = Math.max(0, Math.cos(bike.groundAngle - Math.atan2(-g.x, g.y)));
    var weight = (CONFIG.bikeMass + CONFIG.riderMass) * gravity * load;
    [[bike.rear, bike.rearOnGround, 0.55], [bike.front, bike.frontOnGround, 0.45]].forEach(function (e) {
      if (!e[1]) return;
      var f = CONFIG.rollingResistance * weight * e[2];
      e[0].wheel.applyForceToCenter(Vec2(-ux * f, -uy * f), true);
    });
  }

  // --- How much of the motor's torque reaches the wheel right now (0..1) ---
  //  1. Traction control (a feature of the real bike): cuts power when the
  //     rear tyre spins too much faster than the bike is moving.
  //  2. Rider throttle help (CONFIG.throttleControl, 0..1): eases the throttle
  //     when the front wheel comes up too high. 0 = real life: hold full
  //     throttle without leaning forward and the bike loops out.
  function throttleFactor(bike) {
    if (!bike.rearOnGround) return 1;
    var f = CONFIG.tractionControl ? wheelspinControl(bike) : 1;
    // Keep the front wheel on the ground: as it unloads, cut the power
    // (only when the nose lifts compared with the slope; on a ramp lip the front
    // unloads because the ground curves up, and the power should stay on)
    var rel = bike.chassis.getAngle() - bike.groundAngle;
    var noseUp = -Math.atan2(Math.sin(rel), Math.cos(rel));
    var lifting = Math.max(0, Math.min(1, noseUp / 0.02));
    var keepDown = 1 - lifting * (1 - loadShare(bike.frontLoad, bike));
    return f * (1 - CONFIG.throttleControl * (1 - Math.min(wheelieControl(bike), keepDown)));
  }

  // 1 when a wheel carries a fair share of the weight, falling to 0 as it
  // is about to lift off the ground
  function loadShare(load, bike) {
    var W = (CONFIG.bikeMass + CONFIG.riderMass) * Vec2.lengthOf(bike.world.getGravity());
    return Math.max(0, Math.min(1, (load - 0.03 * W) / (0.07 * W)));
  }

  // Brake assist for one wheel: no stoppies, no locked wheel (ABS-like)
  function brakeShare(bike, which, otherLoad) {
    var a = CONFIG.brakeAssist;
    if (!(a > 0)) return 1;
    var slip = which === "front" ? bike.slipFront : bike.slipRear;
    var target = slip <= CONFIG.slipFull ? 1 : Math.max(0.1, 1 - (slip - CONFIG.slipFull) / 4);
    var key = which === "front" ? "absFront" : "absRear";
    bike[key] += (target - bike[key]) * 0.35;
    // front brake must not lift the rear; rear brake must not lift... nothing (it just must not lock)
    var down = which === "front" ? loadShare(otherLoad, bike) : 1;
    return 1 - a * (1 - Math.min(bike[key], down));
  }

  // Keeps the tyre surface within a few m/s of the bike's speed
  function wheelspinControl(bike) {
    var c = bike.chassis, vel = c.getLinearVelocity();
    var surface = (bike.rear.wheel.getAngularVelocity() - c.getAngularVelocity()) * bike.rear.radius;
    var slip = surface - Math.hypot(vel.x, vel.y);
    var allowed = CONFIG.maxWheelspin;
    var target = slip <= allowed ? 1 : Math.max(0.15, 1 - (slip - allowed));
    // Ease towards it instead of jumping (one full-torque step adds about
    // 3 m/s of slip, so jumping would switch the power on and off every step)
    bike.traction += (target - bike.traction) * 0.25;
    return bike.traction;
  }

  function wheelieControl(bike) {
    // Only once the front wheel is actually up
    if (bike.frontAir < 3) return 1;
    // How far the nose is pointing up compared to the ground under the
    // rear tyre (on a hill, "level" is the slope, not flat)
    var a = bike.chassis.getAngle() - bike.groundAngle;
    var noseUp = -Math.atan2(Math.sin(a), Math.cos(a));
    // Look a moment ahead: a fast-rising front wheel needs easing off sooner
    noseUp += Math.max(0, -bike.chassis.getAngularVelocity()) * 0.25;
    var start = CONFIG.wheelieLimit - 0.35;
    if (noseUp <= start) return 1;
    return Math.max(0, 1 - (noseUp - start) / 0.35);
  }

  // --- Apply player controls. Called once per physics step. ---
  // input: { gas, brake, leanBack, leanForward, holdStill }
  // holdStill = brake without ever reversing (start line, after the finish)
  function control(bike, input) {
    var c = bike.chassis;
    var vel = c.getLinearVelocity();
    var fwd = c.getWorldVector(Vec2(1, 0));
    var forwardSpeed = vel.x * fwd.x + vel.y * fwd.y;
    var rearJ = bike.rear.joint, frontJ = bike.front.joint;
    var Rr = bike.rear.radius;

    if (input.gas) {
      // Electric motor: full torque up to the speed where it reaches full
      // power, then constant power (torque falls as the wheel spins faster)
      var wheelSpin = Math.abs(bike.rear.wheel.getAngularVelocity() - c.getAngularVelocity());
      var roadSpeed = wheelSpin * Rr;
      var fade = roadSpeed <= CONFIG.powerFadeStart ? 1 :
        1 - (1 - CONFIG.powerFadeEnd) * Math.min(1, (roadSpeed - CONFIG.powerFadeStart) / Math.max(1, CONFIG.topSpeed - CONFIG.powerFadeStart));
      var torque = Math.min(CONFIG.wheelTorque, CONFIG.motorPower * fade / Math.max(wheelSpin, 1));
      var targetSpin = CONFIG.topSpeed / Rr;
      // Throttle help in the air: the rider holds the throttle steady instead
      // of pinning it, so the wheel keeps pace with the bike (a racing wheel
      // twists the bike nose-up). 0 = real life, full throttle in the air.
      if (CONFIG.throttleControl > 0 && bike.rearAir > 5 && bike.frontAir > 5 && !input.leanBack) { // (leaning back = going for a flip: full throttle lifts the nose)
        var matched = Math.min(targetSpin, Math.hypot(vel.x, vel.y) / Rr);
        targetSpin += (matched - targetSpin) * Math.min(1, CONFIG.throttleControl);
      }
      rearJ.enableMotor(true);
      rearJ.setMotorSpeed(targetSpin);
      rearJ.setMaxMotorTorque(torque * throttleFactor(bike));
      frontJ.enableMotor(false);
    } else if (input.brake) {
      if (forwardSpeed > 0.5 || input.holdStill) {
        // Front and rear brakes. Like a real rider, ease the front brake
        // when the rear wheel starts lifting (stops you going over the bars)
        // (and let go of the rear brake: stopping the lifted, spinning rear
        // wheel would throw its spin into the frame and flip the bike)
        var front = CONFIG.frontBrakeTorque, rear = CONFIG.rearBrakeTorque;
        if (bike.frontOnGround && bike.rearAir > 2) {
          // Rear wheel up (a "stoppie"): ease the front brake right off as the
          // nose goes down, and off completely while it is still dropping, so
          // the rear comes back down instead of going over the bars
          var a = c.getAngle() - bike.groundAngle;
          var noseDown = Math.atan2(Math.sin(a), Math.cos(a));
          front *= c.getAngularVelocity() > 0 ? 0 : 0.25 * Math.max(0, Math.min(1, 1 - noseDown / 0.1));
          rear = 0;
        }
        if (!input.holdStill) { // (the start-line / after-finish hold needs full brakes)
          front *= brakeShare(bike, "front", bike.rearLoad);
          rear *= brakeShare(bike, "rear", 0);
        }
        rearJ.enableMotor(true); rearJ.setMotorSpeed(0); rearJ.setMaxMotorTorque(rear);
        frontJ.enableMotor(true); frontJ.setMotorSpeed(0); frontJ.setMaxMotorTorque(front);
      } else {
        // Stopped: the motor drives backwards (strong enough to back up a hill)
        rearJ.enableMotor(true);
        rearJ.setMotorSpeed(-CONFIG.reverseSpeed / Rr);
        rearJ.setMaxMotorTorque(CONFIG.reverseTorque);
        // If it still rolls forward (a downhill too steep to back up), the
        // front brake holds it instead of letting it creep down
        if (forwardSpeed > 0.02 && !(bike.rearAir > 2)) {
          frontJ.enableMotor(true); frontJ.setMotorSpeed(0); frontJ.setMaxMotorTorque(CONFIG.frontBrakeTorque);
        } else {
          frontJ.enableMotor(false);
        }
      }
    } else {
      // Off the throttle: engine braking (regen) on the rear wheel, fading to
      // nothing at a standstill so the bike doesn't hold itself on a slope.
      // Only while the tyre is on the ground (it would otherwise tip the nose
      // down in the air).
      var surfaceSpeed = Math.abs(bike.rear.wheel.getAngularVelocity() - c.getAngularVelocity()) * Rr;
      var regen = bike.rearOnGround ? CONFIG.regenTorque * Math.min(1, surfaceSpeed / 3) : 0;
      rearJ.enableMotor(true); rearJ.setMotorSpeed(0); rearJ.setMaxMotorTorque(Math.max(20, regen));
      frontJ.enableMotor(false);
    }

    var lean = (input.leanForward ? 1 : 0) - (input.leanBack ? 1 : 0);

    // The rider shifts their weight (real physics through the hip joint).
    // Braking hard without leaning: the rider shifts back on their own.
    var target = lean > 0 ? CONFIG.riderLeanForward : lean < 0 ? -CONFIG.riderLeanBack : 0;
    if (lean === 0 && input.brake && !input.gas && forwardSpeed > 1) target = -0.6 * CONFIG.riderLeanBack;
    if (bike.hips) {
      // Shift weight smoothly (a real rider can't throw their body instantly)
      var leanSpeed = (target - (bike.rider.getAngle() - c.getAngle())) * 10;
      bike.hips.setMotorSpeed(Math.max(-CONFIG.riderLeanSpeed, Math.min(CONFIG.riderLeanSpeed, leanSpeed)));
    }

    // Flip assist: a little extra turning in the air so flips are possible
    // (0 = real life). Never on the ground, so wheelies stay real.
    if (lean !== 0 && CONFIG.flipAssist > 0 && !touching(bike)) {
      var wSpin = c.getAngularVelocity();
      if (!(Math.abs(wSpin) >= CONFIG.maxSpinSpeed && Math.sign(wSpin) === lean)) {
        c.applyTorque(lean * CONFIG.flipAssist, true);
      }
    }
  }

  // Put the rider in the forward-leaning position (used when restarting after a
  // crash, so holding gas + lean forward doesn't loop the bike out)
  function leanForward(bike) {
    var peg = bike.chassis.getWorldPoint(v(GEO.footpeg)), a = CONFIG.riderLeanForward;
    var p = bike.rider.getPosition(), dx = p.x - peg.x, dy = p.y - peg.y;
    bike.rider.setTransform(Vec2(peg.x + dx * Math.cos(a) - dy * Math.sin(a), peg.y + dx * Math.sin(a) + dy * Math.cos(a)),
      bike.rider.getAngle() + a);
  }

  // --- The rider lets go when they crash ---
  function letGo(bike) {
    if (bike.crashed) return;
    bike.crashed = true;
    bike.world.destroyJoint(bike.hips);
    bike.legStops.forEach(function (j) { bike.world.destroyJoint(j); });
    bike.hips = null;
    bike.rear.joint.enableMotor(false);
    bike.front.joint.enableMotor(false);
  }

  // --- After each physics step: what is touching the ground? ---
  // A wheel counts as "on the ground" if it touched in the last few steps
  // (bumps can lift it for a single step).
  var CONTACT_GRACE_STEPS = 3;

  function touchesGround(body, onlyFixtures) {
    for (var ce = body.getContactList(); ce; ce = ce.next) {
      var ct = ce.contact;
      if (!ct.isTouching() || !ct.isEnabled() || ce.other.getUserData() !== "ground") continue;
      if (!onlyFixtures) return true;
      var mine = ct.getFixtureA().getBody() === body ? ct.getFixtureA() : ct.getFixtureB();
      if (onlyFixtures.indexOf(mine.getUserData()) >= 0) return true;
    }
    return false;
  }

  // Angle of the ground under a wheel (0 = flat), from the contact normal
  function groundAngleUnder(wheel) {
    for (var ce = wheel.getContactList(); ce; ce = ce.next) {
      var ct = ce.contact;
      if (!ct.isTouching() || !ct.isEnabled() || ce.other.getUserData() !== "ground") continue;
      var wm = ct.getWorldManifold(null), n = wm.normal, c = wheel.getPosition(), p = wm.points[0];
      var nx = n.x, ny = n.y;
      if (p && (c.x - p.x) * nx + (c.y - p.y) * ny < 0) { nx = -nx; ny = -ny; } // point away from the ground
      return Math.atan2(nx, -ny);
    }
    return null;
  }

  // How hard the ground pushes the rear tyre forward (the drive force, N),
  // from the friction the physics engine applied at the contact
  function driveForce(bike) {
    var w = bike.rear.wheel, fwd = bike.chassis.getWorldVector(Vec2(1, 0)), F = 0;
    for (var ce = w.getContactList(); ce; ce = ce.next) {
      var ct = ce.contact;
      if (!ct.isTouching() || !ct.isEnabled() || ce.other.getUserData() !== "ground") continue;
      var n = ct.getWorldManifold(null).normal, m = ct.getManifold();
      var sign = ct.getFixtureB().getBody() === w ? 1 : -1; // force on the wheel, not the ground
      for (var k = 0; k < m.pointCount; k++) {
        // friction acts along the tangent (n.y, -n.x)
        F += sign * m.points[k].tangentImpulse * (n.y * fwd.x - n.x * fwd.y);
      }
    }
    return F / CONFIG.physicsStepSec;
  }

  // How far the legs are bent from the attack position (m, + = crouching)
  // (a = chassis angle, peg = footpeg and r = rider origin in world metres)
  function crouchOf(a, peg, r) {
    return (r.x - peg.x) * -Math.sin(a) + (r.y - peg.y) * Math.cos(a);
  }

  function updateContacts(bike) {
    if (bike.hips) {
      bike.crouch = crouchOf(bike.chassis.getAngle(), bike.chassis.getWorldPoint(v(GEO.footpeg)), bike.rider.getPosition());
      // Rider's up/down acceleration (g), averaged over 3 steps: a landing too
      // hard for the legs to hold throws the rider off
      var rv = bike.rider.getLinearVelocity(), dt = CONFIG.physicsStepSec;
      if (bike.riderVel) {
        bike.riderAccel.shift();
        // along the bike's up axis (so it also works under flipped or sideways gravity)
        var up = bike.chassis.getWorldVector(Vec2(0, -1));
        bike.riderAccel.push(((rv.x - bike.riderVel.x) * up.x + (rv.y - bike.riderVel.y) * up.y) / dt / 9.81); // + = pushed up
        bike.riderG = (bike.riderAccel[0] + bike.riderAccel[1] + bike.riderAccel[2]) / 3;
      }
      bike.riderVel = { x: rv.x, y: rv.y };
    }
    bike.rearDrive = driveForce(bike);
    var ga = groundAngleUnder(bike.rear.wheel);
    if (ga !== null) bike.groundAngle = ga;
    bike.rearAir = touchesGround(bike.rear.wheel) ? 0 : bike.rearAir + 1;
    bike.frontAir = touchesGround(bike.front.wheel) ? 0 : bike.frontAir + 1;
    bike.rearOnGround = bike.rearAir < CONTACT_GRACE_STEPS;
    bike.frontOnGround = bike.frontAir < CONTACT_GRACE_STEPS;
    bike.bodyOnGround = touchesGround(bike.chassis);
    // The rider's head or body hitting the ground = crash
    bike.riderHit = touchesGround(bike.rider, ["head", "torso"]);
  }

  // =====================================================
  // DRAWING (everything in metres; game.js sets the scale)
  // =====================================================
  var images = {};
  function loadArt() {
    Object.keys(ART).forEach(function (key) {
      var img = new Image();
      img.src = ART[key];
      images[key] = img;
    });
  }
  function ready(img) { return img && img.complete && img.naturalWidth > 0; }

  // Where each picture goes, in metres (see art/README.md)
  var PLACE = {
    bike:  { x: -1.10, y: -0.75, w: 2.20, h: 1.10 },  // relative to chassis centre
    rider: { x: -0.512, y: -1.615, w: 0.853, h: 1.671 } // relative to footpeg
  };

  // A "pose" is where each part is: { chassis, rear, front, rider } each
  // { x, y, a } (metres, radians), plus crashed. Drawing works from a pose so
  // the ghost bike (a recording of your best run) can be drawn the same way.
  function poseOf(bike) {
    function part(b) { var p = b.getPosition(); return { x: p.x, y: p.y, a: b.getAngle() }; }
    return { chassis: part(bike.chassis), rear: part(bike.rear.wheel), front: part(bike.front.wheel),
             rider: part(bike.rider), crashed: bike.crashed };
  }

  // A point given relative to a part, in world metres
  function toWorld(part, p) {
    var c = Math.cos(part.a), s = Math.sin(part.a);
    return { x: part.x + p.x * c - p.y * s, y: part.y + p.x * s + p.y * c };
  }

  function inPartSpace(ctx, part, fn) {
    ctx.save();
    ctx.translate(part.x, part.y);
    ctx.rotate(part.a);
    fn();
    ctx.restore();
  }

  function metalLine(ctx, a, b, width, dark, light) {
    ctx.lineCap = "round";
    ctx.strokeStyle = dark; ctx.lineWidth = width;
    ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
    ctx.strokeStyle = light; ctx.lineWidth = width * 0.35;
    ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
  }

  function drawWheel(ctx, w, R, img) {
    inPartSpace(ctx, w, function () {
      if (ready(img)) ctx.drawImage(img, -R, -R, 2 * R, 2 * R);
      else { ctx.fillStyle = "#111"; ctx.beginPath(); ctx.arc(0, 0, R, 0, Math.PI * 2); ctx.fill(); }
    });
  }

  // Two-bone arm from shoulder to handlebar grip (elbow bends down/back)
  function drawArm(ctx, shoulder, grip) {
    var upper = 0.34, fore = 0.35; // 6 ft rider: upper arm, forearm + hand to the grip
    var dx = grip.x - shoulder.x, dy = grip.y - shoulder.y;
    var d = Math.min(Math.hypot(dx, dy), upper + fore - 0.001);
    var a = Math.atan2(dy, dx);
    var bend = Math.acos((upper * upper + d * d - fore * fore) / (2 * upper * d));
    var elbow = { x: shoulder.x + Math.cos(a + bend) * upper, y: shoulder.y + Math.sin(a + bend) * upper };
    ctx.lineCap = "round"; ctx.lineJoin = "round";
    ctx.strokeStyle = "#f2f3f5"; ctx.lineWidth = 0.11;
    ctx.beginPath(); ctx.moveTo(shoulder.x, shoulder.y); ctx.lineTo(elbow.x, elbow.y); ctx.lineTo(grip.x, grip.y); ctx.stroke();
    ctx.strokeStyle = "#1d1f23"; ctx.lineWidth = 0.035; // jersey stripe
    ctx.beginPath(); ctx.moveTo(shoulder.x, shoulder.y); ctx.lineTo(elbow.x, elbow.y); ctx.stroke();
    ctx.fillStyle = "#151515"; // glove
    ctx.beginPath(); ctx.arc(grip.x, grip.y, 0.055, 0, Math.PI * 2); ctx.fill();
  }

  function draw(ctx, bike) {
    drawPose(ctx, poseOf(bike));
  }

  function drawPose(ctx, P) {
    var c = P.chassis;
    // Swingarm (back) and fork (front) connect the frame to the moving wheels
    metalLine(ctx, toWorld(c, GEO.swingPivot), P.rear, 0.09, "#3a3a40", "#8d8d96");
    var forkTop = toWorld(c, GEO.forkTop);
    drawWheel(ctx, P.rear, CONFIG.rearWheelRadius, images.rearWheel);
    drawWheel(ctx, P.front, CONFIG.frontWheelRadius, images.wheel);

    // Frame, engine, seat and plastics
    inPartSpace(ctx, c, function () {
      var B = PLACE.bike;
      if (ready(images.bike)) ctx.drawImage(images.bike, B.x, B.y, B.w, B.h);
      else { ctx.fillStyle = "#e8742a"; ctx.fillRect(-0.48, -0.22, 0.96, 0.34); }
    });

    // Front fork: silver tube from the clamp, gold leg sliding to the axle
    var frontAxle = P.front;
    metalLine(ctx, forkTop, frontAxle, 0.07, "#1d1d22", "#c9c9d1");
    var dx = frontAxle.x - forkTop.x, dy = frontAxle.y - forkTop.y, len = Math.hypot(dx, dy) || 1;
    var legTop = { x: frontAxle.x - dx / len * 0.42, y: frontAxle.y - dy / len * 0.42 };
    metalLine(ctx, legTop, frontAxle, 0.10, "#b8860b", "#f7d774");

    // Rider (body picture + arms reaching to the handlebar). When the legs
    // bend the body drops; the boots stay on the pegs, so the picture squashes.
    var crouch = P.crashed ? 0 : crouchOf(c.a, toWorld(c, GEO.footpeg), P.rider);
    inPartSpace(ctx, P.rider, function () {
      var R = PLACE.rider;
      if (ready(images.rider)) ctx.drawImage(images.rider, R.x, R.y, R.w, R.h - crouch);
      else { ctx.fillStyle = "#5a2d82"; ctx.fillRect(-0.26, -1.09, 0.24, 0.5); }
    });
    if (!P.crashed) drawArm(ctx, toWorld(P.rider, GEO.shoulder), toWorld(c, GEO.grip));
  }

  return {
    create: create,
    remove: remove,
    control: control,
    suspension: suspension,
    resistance: resistance,
    compression: compression,
    letGo: letGo,
    updateContacts: updateContacts,
    applyTuning: applyTuning,
    onGround: onGround,
    touching: touching,
    tyreGrip: tyreGrip,
    leanForward: leanForward,
    loadArt: loadArt,
    poseOf: poseOf,
    draw: draw,
    drawPose: drawPose
  };
})();
